library(testthat)
library(staRz)
test_check("staRz") 