context("test-soft.thresh")
test_that("simple errors for bad input", {
  # need to fill with tests!
})