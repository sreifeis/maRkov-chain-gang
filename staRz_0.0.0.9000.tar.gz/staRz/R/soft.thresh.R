#' Soft Threshold
#'
#' This function does...
#' 
#' @param z description
#' @param lambda description
#' 
#' @return a scalar value
#' 
#' @examples 
#' give examples
#'
#' @export
soft.thresh <- function(z, lambda){
  soft_thresh(z, lambda)
}